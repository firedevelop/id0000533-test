<?php

$db = new Database();
return $db->getConn();
